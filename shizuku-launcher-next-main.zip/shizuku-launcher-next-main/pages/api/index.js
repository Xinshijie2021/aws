export default function handler(req, res) {
    res.send("App is working");
}